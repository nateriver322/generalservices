package com.generalservicesportal.joborder.service;


import com.generalservicesportal.joborder.model.Ticket;
import com.generalservicesportal.joborder.repository.TicketRepository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;



    public void saveTicket(Ticket ticket) {
        ticketRepository.save(ticket);
    }

    public Ticket findTicketById(Long id) {
        return ticketRepository.findById(id).orElse(null);
    }

    public List<Ticket> findTicketsByUsername(String username) {
        return ticketRepository.findByUsername(username);
    }

    public List<Ticket> findTicketsByAssignedPersonnel(String assignedPersonnel) {
        return ticketRepository.findByAssignedPersonnel(assignedPersonnel);
    }

    public Optional<Ticket> getTicketById(Long id) {
        return ticketRepository.findById(id);
    }

    public List<Ticket> findAllTickets() {
        return ticketRepository.findAll();
    }

    public void deleteTicket(Long id) {
        ticketRepository.deleteById(id);
    }

    public void assignTicketToPersonnel(Long ticketId, String personnelUsername) {
        Ticket ticket = ticketRepository.findById(ticketId).orElseThrow(() -> new RuntimeException("Ticket not found"));
        ticket.setAssignedPersonnel(personnelUsername);
        ticket.setStatus("Working");
        ticketRepository.save(ticket);
    }
}
