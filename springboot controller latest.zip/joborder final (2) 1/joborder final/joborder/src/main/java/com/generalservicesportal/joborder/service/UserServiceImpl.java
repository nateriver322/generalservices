package com.generalservicesportal.joborder.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.generalservicesportal.joborder.model.Ticket;
import com.generalservicesportal.joborder.model.User;
import com.generalservicesportal.joborder.repository.TicketRepository;
import com.generalservicesportal.joborder.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private TicketRepository ticketRepository;

    @Override
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User findUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public User findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    @Override
    public User findUserById(int id) {  // Add this method
        return userRepository.findById(id).orElse(null);
    }
    
    @Override
    public List<User> findAllUsers() {
        return userRepository.findAll();
    }
    
    @Override
    public void deleteUserById(int id) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            // Delete the tickets associated with the user
            List<Ticket> tickets = ticketRepository.findByUsername(user.getUsername());
            if (tickets != null) {
                ticketRepository.deleteAll(tickets);
            }
            // Delete the user
            userRepository.deleteById(id);
        }
    }
    
    @Override
    public List<User> findPersonnel() {
        return userRepository.findByRole("Personnel");
    }
    
    @Override
    public List<User> searchUsersByUsername(String query) {
        return userRepository.findByUsernameContainingIgnoreCase(query);
    }
    
    @Override
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
}
