package com.generalservicesportal.joborder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoborderApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoborderApplication.class, args);
	}

}
