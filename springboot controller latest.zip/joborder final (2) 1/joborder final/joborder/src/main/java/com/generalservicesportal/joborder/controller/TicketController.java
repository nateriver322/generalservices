package com.generalservicesportal.joborder.controller;

import com.generalservicesportal.joborder.model.Ticket;
import com.generalservicesportal.joborder.service.TicketService;

import java.io.IOException;
import java.util.Base64;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api")
@CrossOrigin
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @PostMapping("/tickets")
    @Transactional
    public ResponseEntity<?> uploadTicket(@RequestParam("image") Optional<MultipartFile> optionalFile,
                                          @RequestParam("username") String username,
                                          @RequestParam("priority") String priority,
                                          @RequestParam("workType") String workType,
                                          @RequestParam("requestType") String requestType,
                                          @RequestParam("location") String location,
                                          @RequestParam("datetime") String datetime,
                                          @RequestParam("description") String description) {
        try {
            Ticket ticket = new Ticket();
            ticket.setUsername(username);
            ticket.setPriority(priority);
            ticket.setWorkType(workType);
            ticket.setRequestType(requestType);
            ticket.setLocation(location);
            ticket.setDatetime(datetime);
            ticket.setDescription(description);
            ticket.setStatus("Pending"); // Set the default status to "pending"

            if (optionalFile.isPresent() && !optionalFile.get().isEmpty()) {
                byte[] imageBytes = optionalFile.get().getBytes();
                ticket.setImage(imageBytes);
            }

            ticketService.saveTicket(ticket);
            return ResponseEntity.ok("Ticket successfully submitted");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error handling image file: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving ticket: " + e.getMessage());
        }
    }


    @GetMapping("/tickets/user/{username}")
    public ResponseEntity<List<Ticket>> getTicketsByUsername(@PathVariable String username) {
        try {
            List<Ticket> tickets = ticketService.findTicketsByUsername(username);
            tickets.forEach(ticket -> {
                if (ticket.getImage() != null) {
                    // Convert the image byte array to Base64
                    String imageBase64 = Base64.getEncoder().encodeToString(ticket.getImage());
                    ticket.setImageBase64(imageBase64);
                    // Nullify the image byte array to not send as binary data
                    ticket.setImage(null);
                }
            });
            if (!tickets.isEmpty()) {
                return ResponseEntity.ok(tickets);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }
    
    @GetMapping("/tickets")
    public ResponseEntity<List<Ticket>> getAllTickets() {
        try {
            List<Ticket> tickets = ticketService.findAllTickets();
            tickets.forEach(ticket -> {
                if (ticket.getImage() != null) {
                    String imageBase64 = Base64.getEncoder().encodeToString(ticket.getImage());
                    ticket.setImageBase64(imageBase64);
                    ticket.setImage(null);
                }
            });
            return ResponseEntity.ok(tickets);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }
    
    @DeleteMapping("/tickets/{id}")
    public ResponseEntity<?> deleteTicket(@PathVariable Long id) {
        try {
            Optional<Ticket> ticket = ticketService.getTicketById(id);
            if (ticket.isPresent()) {
                ticketService.deleteTicket(id);
                return ResponseEntity.ok("Ticket successfully deleted");
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting ticket: " + e.getMessage());
        }
    }
    
    @PostMapping("/tickets/assign")
    public ResponseEntity<?> assignTicketToPersonnel(@RequestParam Long ticketId, @RequestParam String personnelUsername) {
        try {
            Optional<Ticket> optionalTicket = ticketService.getTicketById(ticketId);
            if (optionalTicket.isPresent()) {
                Ticket ticket = optionalTicket.get();
                ticket.setAssignedPersonnel(personnelUsername);
                ticket.setStatus("Working"); // Update the status to Working
                ticketService.saveTicket(ticket);
                return ResponseEntity.ok("Ticket successfully assigned");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Ticket not found");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error assigning ticket: " + e.getMessage());
        }
    }

    @GetMapping("/tickets/personnel/{personnelUsername}")
    public ResponseEntity<List<Ticket>> getTicketsByPersonnel(@PathVariable String personnelUsername) {
        try {
            List<Ticket> tickets = ticketService.findTicketsByAssignedPersonnel(personnelUsername);
            tickets.forEach(ticket -> {
                if (ticket.getImage() != null) {
                    String imageBase64 = Base64.getEncoder().encodeToString(ticket.getImage());
                    ticket.setImageBase64(imageBase64);
                    ticket.setImage(null);
                }
            });
            return ResponseEntity.ok(tickets);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }
    
    @PostMapping("/assign")
    public ResponseEntity<?> assignTicket(@RequestParam Long ticketId, @RequestParam String personnelUsername) {
        ticketService.assignTicketToPersonnel(ticketId, personnelUsername);
        return ResponseEntity.ok("Ticket successfully assigned");
    }
}
