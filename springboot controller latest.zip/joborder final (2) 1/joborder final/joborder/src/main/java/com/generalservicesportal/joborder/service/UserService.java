package com.generalservicesportal.joborder.service;

import java.util.List;

import com.generalservicesportal.joborder.model.User;

public interface UserService {
	public User saveUser(User user);
	public User findUserByEmail(String email);
	User findUserByUsername(String username);
	User findUserById(int id);
	List<User> findAllUsers();
	void deleteUserById(int id);
	List<User> searchUsersByUsername(String query);
	boolean existsByEmail(String email);
	List<User> findPersonnel();
	

}
